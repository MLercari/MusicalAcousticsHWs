
Students : 10743504, 10751919

for Ex. 1: compute file "HWL1_bell_light.mph"
for Ex. 2: compute 2DAx.mph"